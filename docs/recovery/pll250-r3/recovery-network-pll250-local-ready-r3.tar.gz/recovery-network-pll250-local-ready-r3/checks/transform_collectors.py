"""Exact-fragment edits preserve all unrelated local collector/performance fixes.
No broad regex replacement and no fallback to an older complete file.
"""
from pathlib import Path

def once(text, old, new, name):
    if text.count(old) != 1:
        raise ValueError(f'{name}: expected fragment count 1, observed {text.count(old)}; merge/review required')
    return text.replace(old, new, 1)

def transform(name, text):
    def edit(old, new):
        nonlocal text
        text=once(text,old,new,name)
    if name=='native_quarter_clock_constraints.tcl':
        start=text.index('proc valence_quarter_tx_clocks {hier} {')
        end=text.index('proc valence_quarter_data_pin',start)
        old=text[start:end]
        # Guard the exact legacy proc body; arbitrary local changes need review.
        import hashlib
        if hashlib.sha256(old.encode()).hexdigest() != '0de86b5d1f82c30f9378a47667991f111ff7552650862b6b3bb5e2aa6b02d505':
            raise ValueError(f'{name}: clock procedure preimage differs; merge/review required')
        edit(old,'''source [file join [file dirname [info script]] native_network_topology.tcl]
proc valence_quarter_tx_clocks {hier} {
    # Callers historically pass network_clock. Configuration selects one exact
    # physical branch. This only audits clocks inferred from real primitives.
    set root [dict get [valence_network_clock::facts] root]
    if {$hier ni [list network_clock $root]} {error "Unexpected network clock root: $hier"}
    return [valence_network_clock::audit $root]
}
''')
        edit('proc valence_quarter_tx_audit {hier} {','''proc valence_quarter_tx_audit {hier} {
    if {[dict get [valence_network_clock::facts] startup_align]} {
        error "Old alternate serializer audit cannot qualify split startup resets; use bound native_mac_roles"
    }''')
    elif name=='board_controls.tcl':
        edit('if {[llength $v]!=1} {error "Expected exactly one $kind $name; got $v"}',
             'if {[llength $v]!=1 || [get_property NAME $v] ne $name} {error "Expected exact unique $kind $name; got $v"}')
        edit('proc v_reset_release {base active_low {phase_dividers 0}} {','''proc v_reset_release {base active_low {phase_dividers 0}} {
 set topology [valence_network_clock::facts]
 if {$phase_dividers} {
  if {$base ne [dict get $topology phase_base] || $active_low} {error "Phase exception only for configured exact three-stage chain"}
  # This proves the PAD-buffer/PLL250 sibling relation, complete FF/logic and
  # exact early fanout BEFORE the inherited release-FF-only async cut.
  valence_network_clock::audit [dict get $topology root]
 }''')
        edit('''    if {$base ne "network_clock/phase_reset_reg" || $active_low} {error "Divider exception only applies to exact frozen phase sequencer"}
    foreach div {network_clock/raw_div network_clock/quarter_div} {
     if {[get_property REF_NAME [v_one get_cells $div]] ne "BUFGCE_DIV" || [get_nets -of_objects [v_one get_pins $div/I]] ne $clock} {error "Phase-reset divider source clock mismatch"}
     lappend expected [v_one get_pins $div/CLR]
    }''','''    set dividers [list [dict get $topology raw]]
    if {![dict get $topology pll250]} {lappend dividers [dict get $topology pad]}
    foreach div $dividers {
     # Source relation was proved above. ON I is direct PLL250, phase C is
     # buffered PAD250; OFF both I/C originate at the REF500 delay buffer.
     lappend expected [v_one get_pins $div/CLR]
    }''')
        edit('proc v_clock_placement {} {','proc v_clock_placement {} {\n set topology [valence_network_clock::facts]')
        edit('set_property LOC [lindex $plls 0] [v_one get_cells network_clock/pll]','set_property LOC [lindex $plls 0] [v_one get_cells [dict get $topology pll]]')
        edit('set_property PHASESHIFT_MODE WAVEFORM [get_cells network_clock/pll]','set_property PHASESHIFT_MODE WAVEFORM [v_one get_cells [dict get $topology pll]]')
        edit('foreach path {rx_clock_buffer network_clock/raw_div network_clock/quarter_div network_clock/delay_buffer u_soc/nativeBank/gmac/txManaged_gate/buffer u_soc/nativeBank/gmac/rxManaged_gate/buffer} {',
             'foreach path [list rx_clock_buffer [dict get $topology raw] [dict get $topology pad] [dict get $topology delay] u_soc/nativeBank/gmac/txManaged_gate/buffer u_soc/nativeBank/gmac/rxManaged_gate/buffer] {')
        edit('[get_pins network_clock/quarter_div/O]', '[v_one get_pins [dict get $topology pad]/O]')
        edit('v_reset_release network_clock/phase_reset_reg 0 1','v_reset_release [dict get [valence_network_clock::facts] phase_base] 0 1')
    elif name=='native_clock_ancestry.tcl':
        edit('proc native_clock_ancestry {} {','proc native_clock_ancestry {} {\n set topology [valence_network_clock::facts]\n set raw [dict get $topology raw]; set pad [dict get $topology pad]')
        edit('network_clock/raw_div/O 8 network_clock/quarter_div/O 4', '$raw/O 8 $pad/O 4')
        edit('native_same_net network_clock/raw_div/O u_soc/nativeBank/gmac/txManaged_gate/buffer/I','native_same_net $raw/O u_soc/nativeBank/gmac/txManaged_gate/buffer/I')
        edit('native_same_net network_clock/raw_div/O u_soc/nativeBank/gmac/rxManaged_gate/buffer/I','native_same_net $raw/O u_soc/nativeBank/gmac/rxManaged_gate/buffer/I')
        edit('# Original real-board divided topology, not an invented sibling raw125 input.', '# Exact configured physical RAW source, still shared by complete packet owners.')
    elif name=='trispeed_board_constraints.tcl':
        edit('proc valence_trispeed_clock_reset_audit {bank mbps} {','proc valence_trispeed_clock_reset_audit {bank mbps} {\n    set topology [valence_network_clock::facts]\n    set raw [dict get $topology raw]; set pad [dict get $topology pad]')
        edit('network_clock/raw_div/O 8.0', '$raw/O 8.0')
        edit('network_clock/quarter_div/O 4.0', '$pad/O 4.0')
        edit('valence_trispeed_same_net network_clock/raw_div/O $bank/$gate/buffer/I', 'valence_trispeed_same_net $raw/O $bank/$gate/buffer/I')
        edit('valence_trispeed_same_net network_clock/raw_div/O $bank/physicalIngress/destinationClock', 'valence_trispeed_same_net $raw/O $bank/physicalIngress/destinationClock')
    else:
        raise ValueError(f'Unrecognized collector {name}')
    return text

if __name__=='__main__':
    import sys
    source,dest=map(Path,sys.argv[1:])
    dest.mkdir(parents=True,exist_ok=True)
    for name in ('native_quarter_clock_constraints.tcl','board_controls.tcl','native_clock_ancestry.tcl','trispeed_board_constraints.tcl'):
        (dest/name).write_text(transform(name,(source/name).read_text()))
