#!/usr/bin/env python3
"""Bind/verify the explicit fresh-synthesis hook's checkpoint bytes.
This receipt is provenance, not functional or physical qualification.
"""
from pathlib import Path
import sys,json
from network_preflight import verify,sha,require
mode,root,checkpoint,p,s=sys.argv[1:];root=Path(root).resolve();checkpoint=Path(checkpoint).resolve();p=int(p);s=int(s)
verify(root,p,s)
receipt=Path(str(checkpoint)+'.network.json')
data=dict(schema='valence-network-checkpoint-v1',checkpoint_sha256=sha(checkpoint),source_binding_sha256=sha(root/'NETWORK_MODE.json'),full_manifest_sha256=sha(root/'FINAL_SOURCE_MANIFEST.json'),top='soc_top_observed_native_ddr',part='xczu15eg-ffvb1156-2-i',pll250=p,startup_align=s,qualification='fresh_hook_provenance_only_not_timing')
if mode=='seal':
    with receipt.open('x') as f:f.write(json.dumps(data,indent=2)+'\n')
else:
    require(mode=='verify' and json.loads(receipt.read_text())==data,'Checkpoint/current-source binding drift')
print('NETWORK_CHECKPOINT_BINDING_PASS '+data['source_binding_sha256'])
