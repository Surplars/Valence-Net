#!/usr/bin/env python3
"""Source-only exact-byte preflight. No vendor execution or checkpoint qualification."""
from pathlib import Path
import hashlib, json, re, sys

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def require(ok, why):
    if not ok: raise RuntimeError(why)

def control_lemma(root):
    forms=json.loads((root/'provenance/CONTROL_SOURCE_FORMS.json').read_text())['rows']
    actual={r['file']:sha(root/'rtl'/r['file']) for r in forms}
    admitted=any(actual=={r['file']:r[k] for r in forms} for k in ('old_sha256','clean_sha256'))
    require(admitted,'Unreviewed complete encoder/parent/forwarding source form; control lemma permission denied')
    encoder=(root/'rtl/TriSpeedRgmiiTx.sv').read_text()
    require(encoder.count('always @(posedge clock or posedge reset) begin')==1,'Encoder process changed')
    for text in ["io_rise_REG <= 5'h0;", "io_fall_REG <= 5'h0;",
                 'io_rise_REG <= {enable, gigabit | ~highNibble ? data[3:0] : data[7:4]};',
                 'io_fall_REG <= {enable, gigabit | highNibble ? data[7:4] : data[3:0]};',
                 'assign io_rise = io_rise_REG;', 'assign io_fall = io_fall_REG;']:
        require(encoder.count(text)==1,'Encoder control induction source mismatch: '+text)
    chain=[('rtl/TriSpeedManagedGmac.sv',[('clock','rawTxClock'),('reset','_rawTxRelease_resetOut'),('io_rise','rgmiiTxRise'),('io_fall','rgmiiTxFall')]),
           ('rtl/ManagedPeripheralBank.sv',[('rgmiiTxRise','triSpeedRgmii_txRise'),('rgmiiTxFall','triSpeedRgmii_txFall')]),
           ('rtl/ObservedBoardSocTop.sv',[('triSpeedRgmii_txRise','io_nativeGmac_triSpeedRgmii_txRise'),('triSpeedRgmii_txFall','io_nativeGmac_triSpeedRgmii_txFall')]),
           ('board/soc_top_observed_native_ddr.sv',[('io_nativeGmac_triSpeedRgmii_txRise','rgmii_tx_rise'),('io_nativeGmac_triSpeedRgmii_txFall','rgmii_tx_fall'),('tx_rise','rgmii_tx_rise'),('tx_fall','rgmii_tx_fall')])]
    for filename,ports in chain:
        text=(root/filename).read_text()
        if filename.endswith('TriSpeedManagedGmac.sv'):
            blocks=re.findall(r'TriSpeedRgmiiTx encode \((.*?)\n  \);',text,re.S)
            require(len(blocks)==1,'Unique full encoder instance required');text=blocks[0]
        for port,net in ports:
            require(len(re.findall(r'\.'+port+r'\s*\('+net+r'\)',text))==1,'Control forwarding mismatch: '+filename+' '+port)
    adapter=root/'board/native_rgmii_trispeed_quarter.sv'
    require(sha(adapter)=='8c07d9b36557399026c3ffa82101ab5332d6277eaf8fd3d6d1d4f377dca7c166','Startup serializer exact source mismatch')
    text=adapter.read_text()
    for snippet in ['always @(negedge tx_pad_clock or posedge fabric_reset)', 'low_symbol<=0; high_symbol<=0;', 'low_symbol<=tx_rise; high_symbol<=tx_fall;']:
        require(text.count(snippet)==1,'Serializer induction source mismatch')
    vectors=0
    for reset in (0,1):
        for phase in (0,1):
            for source in (0,1):
                for prior in (0,1):
                    low=0 if reset else (prior if phase else source)
                    high=0 if reset else (prior if phase else source)
                    require(low==high,'Control reset/phase induction failed');vectors+=1
    return dict(proved=True,reset_phase_induction_vectors=vectors,source_sha256=actual,mapped_chain_checked=False,physical_qualification=False)

def verify(root, pll250, startup, layout='wrapper'):
    root=Path(root).resolve()
    mode=json.loads((root/'NETWORK_MODE.json').read_text())
    require(mode['schema']=='valence-network-source-v1','Wrong network binding schema')
    require(mode['pll250']==pll250 and mode['startup_align']==startup and mode['layout']==layout,'Explicit network flags differ from bound source input')
    require((root/'NETWORK_COLLECTOR_DIR.txt').read_text().strip()==mode['collector_dir'] and mode['collector_dir'] in ('scripts','local-adapt-r3v'),'Collector directory binding drift')
    require(mode['t1']==mode['selected']==0 and layout=='wrapper','Only current0/0 wrapper source is admitted')
    for entry in mode['files']:
        p=root/entry['path']
        require(p.is_file() and not p.is_symlink() and sha(p)==entry['sha256'] and p.stat().st_size==entry['bytes'],'Source binding drift: '+entry['path'])
    require(len(list((root/'rtl').glob('*.sv')))==309,'Require complete current309 RTL closure')
    require(sha(root/'board/native_gmac_pll250_clock.sv')=='fcca17c4d51eeb4a508145aafee72791d513627269e2ebb286614a8654d0aaa8','PLL250 source changed')
    lemma=control_lemma(root)
    require(lemma==mode['control_lemma'],'Fresh control induction differs from bound identity')
    return mode

if __name__=='__main__':
    root=Path(sys.argv[1]);pll250,startup=map(int,sys.argv[2:4]);layout=sys.argv[4] if len(sys.argv)>4 else 'wrapper'
    require(pll250 in (0,1) and startup in (0,1),'Explicit Boolean knobs required')
    mode=verify(root,pll250,startup,layout)
    print('NETWORK_SOURCE_BINDING_PASS '+sha(root/'NETWORK_MODE.json'))
