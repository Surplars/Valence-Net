#!/usr/bin/env python3
"""Narrow edits of the two known local min8 runners into NEW output files.
Requires exact input hashes. Does not execute any runner. All other local hooks
and their order stay verbatim. Postroute invocation is supplied separately.
"""
from pathlib import Path
import argparse,json,hashlib,re,shutil
from transform_collectors import once
from network_preflight import require,sha,verify
HERE=Path(__file__).resolve().parents[1]

HEADER = 'if {$argc != 4} {error "Expected ROOT DEPS RAW50 PYTHON"}\nlassign $argv root deps raw50 python\nset root [file normalize $root];set deps [file normalize $deps];set raw50 [file normalize $raw50]'
OLD_TEMP = 'set shortTemp C:/Users/surplars/AppData/Local/Temp/valence-guarded19-place-r1'

def transform_runner(name,text,newroot,pll250,startup,short_temp):
    def edit(old,new):
        nonlocal text
        text=once(text,old,new,name)
    # Exact reported argv/header, including the shared semicolon line. Do not
    # guess a different header or discard deps/raw50 normalization.
    require(text.count(HEADER)==1,'Actual argc/argv/root header differs; review required')
    require(not text[:text.index(HEADER)].strip() or all(line.lstrip().startswith('#') or not line.strip() for line in text[:text.index(HEADER)].splitlines()),'Unexpected executable code before known header')
    require(not any(c in str(newroot)+str(short_temp) for c in '{}\n\r'),'Unsupported destination Tcl path')
    require(Path(short_temp).is_absolute() and not Path(short_temp).exists(),'Fresh absolute short-temp directory required')
    root_statement='set root [file normalize $root]'
    new_statement='set root [file normalize {'+str(newroot)+'}]'
    edit(root_statement,new_statement)
    # $python is already set by the exact lassign before either inserted load.
    argv_guard='if {[file normalize $root] ne [file normalize {'+str(newroot)+'}]} {error "ROOT argument differs from the bound isolated input"}\n'
    edit(new_statement,argv_guard+new_statement)
    load='source [file join $root local-adapt-r3v native_network_mode.tcl]\nvalence_network_mode::load $root $python '+str(pll250)+' '+str(startup)+'\n'
    if name=='synthesize_min8.tcl':
        require(text.count('source [file join [file dirname [info script]] require_vivado_min8.tcl]')==1,'Synth entry/helper anchor differs')
        edit('native_tx_word_reset_boundary.sv native_rgmii_trispeed_quarter.sv} {read_verilog -sv [file join $root board $name]}', 'native_tx_word_reset_boundary.sv native_rgmii_trispeed_quarter.sv native_gmac_pll250_clock.sv} {read_verilog -sv [file join $root board $name]}')
        edit('read_verilog -sv [lsort [glob [file join $root rtl *.sv]]]',load+'read_verilog -sv [lsort [glob [file join $root rtl *.sv]]]')
        edit('synth_design -top soc_top_observed_native_ddr -flatten_hierarchy none -generic {NATIVE_MAC_LOCAL_PAD_RESET_RELEASE=0 NATIVE_MAC_REGISTER_SELECTED_HALF=0}', 'valence_network_synth_design -flatten_hierarchy none')
        edit('write_checkpoint post_synth_unconstrained.dcp','valence_network_write_checkpoint post_synth_unconstrained.dcp')
    elif name=='place_min8.tcl':
        require(text.count('set entry [file dirname [info script]]')==1 and text.count('source [file join $entry require_vivado_min8.tcl]')==1,'Place entry/helper anchors differ')
        require(text.count('set scripts [file join $root local-adapt-r3v];set out [file join $root implementation]')==1,'Place scripts/out binding differs')
        require(re.findall(r'^set shortTemp [^\n]+$',text,re.M)==[OLD_TEMP],'Exact original shortTemp assignment required')
        edit(OLD_TEMP,'set shortTemp [file normalize {'+str(short_temp)+'}]\nif {[file exists $shortTemp]} {error "Fresh isolated shortTemp required; refusing existing directory"}')
        opens=re.findall(r'^open_checkpoint [^\n]+$',text,re.M)
        require(len(opens)==1 and ';' not in opens[0],'Unique initial open_checkpoint line required')
        require(text.index('lassign $argv root deps raw50 python')<text.index(opens[0]) and text.index('set entry [file dirname [info script]]')<text.index(opens[0]),'Place mode load would precede bound variables')
        edit(opens[0],load+opens[0].replace('open_checkpoint ','valence_network_open_checkpoint ',1))
        # Preserve original full manifest check, exact TOP/PART guard, counter,
        # proof log and every monitor/reset-fold/pruning/performance overlay.
        edit('exec $python [file join $entry verify_mac_control_source_lemma.py] $root', 'valence_network_mode::verify')
        edit('set proof [valence_mac_roles::audit $instance 0 0]', 'valence_network_mode::assert_session\n set proof [valence_mac_roles::audit $instance 0 0 0 '+str(pll250)+' '+str(startup)+']')
    else:raise RuntimeError('Unsupported runner')
    return text

def copy_required_helper(source,dest):
    helper=source/'require_vivado_min8.tcl'
    require(helper.is_file() and not helper.is_symlink(),'Missing/nonregular require_vivado_min8.tcl')
    target=dest/helper.name
    require(not target.exists(),'Fresh helper target required')
    shutil.copy2(helper,target)
    require(sha(helper)==sha(target),'Required helper copy drift')
    return dict(path=helper.name,bytes=helper.stat().st_size,sha256=sha(helper))

def patch(source,dest,root,p,s,short_temp):
    verify(root,p,s)
    require((root/'NETWORK_COLLECTOR_DIR.txt').read_text().strip()=='local-adapt-r3v','Actual local runner requires bound local-adapt-r3v')
    expected=json.loads((HERE/'provenance/KNOWN_PREIMAGES.json').read_text())['local_runners_unprovided']
    require(not dest.exists(),'Fresh runner destination required')
    require((source/'require_vivado_min8.tcl').is_file() and not (source/'require_vivado_min8.tcl').is_symlink(),'Missing/nonregular required helper')
    require(short_temp.is_absolute() and not short_temp.exists(),'Fresh absolute short-temp directory required')
    output={}
    for name,digest in expected.items():
        require(sha(source/name)==digest,'Runner preimage differs: '+name)
        output[name]=transform_runner(name,(source/name).read_text(),root,p,s,short_temp)
    dest.mkdir(parents=True)
    helper=copy_required_helper(source,dest)
    for name,text in output.items():(dest/name).write_text(text)
    receipt=dict(status='PATCHED_SOURCE_ONLY_NOT_EXECUTED',required_helper=helper,short_temp=str(short_temp),header='exact argc4/argv root deps raw50 python; deps/raw50 normalization preserved',remaining_outer_closure='Verify other helpers and unchanged external PYTHON argument locally against ACTUAL_RUNNER_CLOSURE.json SHA2567b9c91cf9712d416283c2aa9d873424a33206db6a038717354e5f6baf7d80536',target_root=str(root),source_manifest_sha256=sha(root/'FINAL_SOURCE_MANIFEST.json'),network_mode_sha256=sha(root/'NETWORK_MODE.json'),before={n:sha(source/n) for n in output},after={n:sha(dest/n) for n in output},postroute_hook_required='valence_network_postroute $rate $out after each fresh rate constraint scenario')
    (dest/'RUNNER_PATCH_BINDING.json').write_text(json.dumps(receipt,indent=2)+'\n')
    return receipt
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('destination',type=Path);p.add_argument('new_root',type=Path);p.add_argument('--short-temp',required=True,type=Path);p.add_argument('--pll250',required=True,type=int,choices=[0,1]);p.add_argument('--startup-align',required=True,type=int,choices=[0,1]);a=p.parse_args()
    print(json.dumps(patch(a.source,a.destination,a.new_root.resolve(),a.pll250,a.startup_align,a.short_temp),indent=2))
