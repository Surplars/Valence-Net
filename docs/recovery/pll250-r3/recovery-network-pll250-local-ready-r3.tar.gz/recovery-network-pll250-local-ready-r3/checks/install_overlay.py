#!/usr/bin/env python3
"""Install a bounded source-only overlay into a NEW copied input root.
Never touches the source root. Does not run synthesis/implementation or a runner.
"""
from pathlib import Path
import argparse,hashlib,json,shutil,sys
from transform_collectors import transform
from network_preflight import control_lemma,verify,require,sha
HERE=Path(__file__).resolve().parents[1]
CHANGED=[f'scripts/{s}' for s in ('board_controls.tcl','native_clock_ancestry.tcl','native_quarter_clock_constraints.tcl','trispeed_board_constraints.tcl','native_mac_roles.tcl')]+['board/soc_top_observed_native_ddr.sv','board/native_rgmii_trispeed_quarter.sv']
ADDED=[f'scripts/{s}' for s in ('native_network_topology.tcl','native_network_mode.tcl','native_network_reset_timing.tcl')]+['board/native_gmac_pll250_clock.sv','checks/network_preflight.py','checks/network_checkpoint.py','provenance/CONTROL_SOURCE_FORMS.json']
def records(root,paths):
    return [dict(path=n,bytes=(root/n).stat().st_size,sha256=sha(root/n)) for n in sorted(paths)]
def install(source,dest,pll250=0,startup=0,script_dir="scripts"):
    require(script_dir in ("scripts","local-adapt-r3v"),"Explicit supported collector directory required")
    changed=[n.replace("scripts/",script_dir+"/",1) if n.startswith("scripts/") else n for n in CHANGED]
    added=[n.replace("scripts/",script_dir+"/",1) if n.startswith("scripts/") else n for n in ADDED]
    source=source.resolve();dest=dest.resolve()
    require(not dest.exists() and source not in dest.parents,'Fresh independent destination required')
    require(pll250 in (0,1) and startup in (0,1),'Boolean flags required')
    # First verify the complete existing local source closure, including its
    # already-reviewed monitor/performance updates. No old cloud substitute.
    original=json.loads((source/'FINAL_SOURCE_MANIFEST.json').read_text())
    names=[]
    for entry in original['files']:
        n=entry['path'];p=source/n
        require(not Path(n).is_absolute() and '..' not in Path(n).parts and p.is_file() and not p.is_symlink(),'Unsafe/missing source '+n)
        require(sha(p)==entry['sha256'] and p.stat().st_size==entry['bytes'],'Existing manifest drift: '+n)
        names.append(n)
    # The local overlay is a separate authoritative input closure. Bind an
    # explicit byte snapshot rather than silently falling back to frozen scripts.
    extra=[]
    if script_dir=="scripts":
        require(not (source/'local-adapt-r3v').exists(),"Actual local-adapt-r3v exists; pass --script-dir local-adapt-r3v explicitly")
    else:
        require((source/script_dir).is_dir(),"Missing actual local collector directory")
        extra=[p.relative_to(source).as_posix() for p in sorted((source/script_dir).rglob('*')) if p.is_file()]
        require(extra and len(extra)<250 and all(not (source/n).is_symlink() for n in extra),"Unbounded/symlink local collector closure")
        names=sorted(set(names+extra))
    require(len(names)==len(set(names)) and len(names)<2500,'Duplicate/unbounded source manifest')
    require(len(list((source/'rtl').glob('*.sv')))==309,'Full309 RTL required')
    require(json.loads((source/'contracts/monitor-banks.json').read_text())['totalCounters']==82,'Monitor82 contract changed')
    require(set(changed).issubset(names),'Patched files absent from original binding')
    preimages=json.loads((HERE/'provenance/KNOWN_PREIMAGES.json').read_text())['files']
    for name in changed+['board/native_gmac_divided_clock.sv','board/native_tx_word_reset_boundary.sv']:
        key=name.replace(script_dir+'/', 'scripts/',1) if name.startswith(script_dir+'/') else name
        require(sha(source/name)==preimages[key],'Unexpected patch preimage: '+name)
    require(sum((source/n).stat().st_size for n in names)<512*1024*1024,'Source copy exceeds bounded512MiB')
    require(shutil.disk_usage(dest.parent).free-sum((source/n).stat().st_size for n in names)>4*1024**3,'Keep4GiB disk floor')
    require(not any((source/n).exists() for n in added),'Overlay already present; do not mix generations')
    dest.mkdir()
    for name in names:
        p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/name,p)
    (dest/'provenance').mkdir(exist_ok=True)
    shutil.copy2(source/'FINAL_SOURCE_MANIFEST.json',dest/'provenance/PARENT_FINAL_SOURCE_MANIFEST.json')
    for name in changed:
        if Path(name).name in ('board_controls.tcl','native_clock_ancestry.tcl','native_quarter_clock_constraints.tcl','trispeed_board_constraints.tcl'):
            (dest/name).write_text(transform(Path(name).name,(source/name).read_text()))
        else:
            key=name.replace(script_dir+'/','scripts/',1) if name.startswith(script_dir+'/') else name
            shutil.copy2(HERE/key,dest/name)
    for name in added:
        key=name.replace(script_dir+'/', 'scripts/',1) if name.startswith(script_dir+'/') else name
        p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(HERE/key,p)
    (dest/'NETWORK_COLLECTOR_DIR.txt').write_text(script_dir+'\n')
    added.append('NETWORK_COLLECTOR_DIR.txt')
    # Complete source/collector bytes are fresh-bound, not an old export receipt.
    boundnames=sorted(set(names+added))
    mode=dict(schema='valence-network-source-v1',t1=0,selected=0,pll250=pll250,startup_align=startup,layout='wrapper',collector_dir=script_dir,files=records(dest,boundnames),control_lemma=control_lemma(dest),physical_qualification=False)
    (dest/'NETWORK_MODE.json').write_text(json.dumps(mode,indent=2)+'\n')
    identity=dict(status='SOURCE_OVERLAY_INSTALLED_VENDOR_PENDING',source_root=str(source),destination=str(dest),source_manifest_sha256=sha(source/'FINAL_SOURCE_MANIFEST.json'),collector_dir=script_dir,local_overlay_snapshot=records(source,extra),patch_inputs=records(source,changed),patch_outputs=records(dest,changed+added),unmodified_files_preserved=len(names)-len(changed),pll250=pll250,startup_align=startup)
    (dest/'provenance/NETWORK_OVERLAY_IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
    # Preserve every original entry except the seven explicitly changed paths.
    # Add only the stated overlay and identity artifacts; original manifest is
    # retained, not overwritten in the source. verify_handoff remains unchanged.
    entries={x['path']:x for x in original['files']}
    for x in records(dest,extra):entries[x['path']]=x
    for x in records(dest,changed+added+['NETWORK_MODE.json','provenance/PARENT_FINAL_SOURCE_MANIFEST.json','provenance/NETWORK_OVERLAY_IDENTITY.json']): entries[x['path']]=x
    final={**original,'status':'SOURCE_OVERLAY_VENDOR_EXECUTION_PENDING','files':[entries[n] for n in sorted(entries)]}
    (dest/'FINAL_SOURCE_MANIFEST.json').write_text(json.dumps(final,indent=2)+'\n')
    for name in set(names)-set(changed): require(sha(source/name)==sha(dest/name),'Unrelated local file changed: '+name)
    verify(dest,pll250,startup)
    return identity
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('destination',type=Path);p.add_argument('--script-dir',choices=['scripts','local-adapt-r3v'],default='scripts');p.add_argument('--pll250',type=int,choices=[0,1],default=0);p.add_argument('--startup-align',type=int,choices=[0,1],default=0)
    a=p.parse_args();print(json.dumps(install(a.source,a.destination,a.pll250,a.startup_align,a.script_dir),indent=2))
