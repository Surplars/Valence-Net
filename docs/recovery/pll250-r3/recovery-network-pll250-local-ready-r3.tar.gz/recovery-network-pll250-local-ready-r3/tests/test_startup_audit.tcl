# Independent whole-audit reset plumbing test. No Vivado execution or timing proof.
# Production audit/ff/startup helpers/qff/value/prove remain live, including the
# bounded serializer equations. Only vendor object queries and clocks() are mocks.
# Uses the pre-existing strict typed-object fixture; its source path is explicit.
set here [file dirname [file normalize [info script]]]
set fixturePath [file join $here typed_mock.tcl]
source $fixturePath
source [file join $here .. scripts native_mac_roles.tcl]
rename valence_mac_roles::clocks valence_mac_roles::unexecuted_clock_topology
proc valence_mac_roles::clocks {hier {require_raw_handoff 0} {pll250 0}} {
    return [dict create raw_pin $hier/tx_clock raw_divider rawDivider pad_divider padDivider witness MOCKED encoder_ffs {} falling_samples {} falling_sample_count 0 required $require_raw_handoff]
}
proc startup_fixture {} {
    fixture 0 0
    # Every fabric FF originally used rawReset; all six ODDRs retain rawReset.
    foreach c [get_property NAME [get_cells -quiet -hier -filter {REF_NAME == FDCE || REF_NAME == FDPE}]] {
        set rp [expr {[dict get $::db cell $c REF_NAME] eq "FDPE" ? "PRE" : "CLR"}]
        dict set ::conn $c/$rp fabricReset
    }
    ff u_rgmii/hold fabricReset ground power 0 1 rawReset
    dict set ::conn u_rgmii/hold/C raw
}
set passed 0
proc expect_audit {name mutation expected {invocation {u_rgmii 0 0 0 1 1}}} {
    startup_fixture
    uplevel #0 $mutation
    set rc [catch {valence_mac_roles::audit {*}$invocation} result opts]
    if {$expected eq "PASS"} {
        if {$rc || ![string match PASS_MAC_ROLE_SEMANTICS* $result]} {
            if {$rc} {puts stderr [dict get $opts -errorinfo]}
            error "$name unexpected failure: $result"
        }
        foreach field {startup=1 {cell u_rgmii/hold} timing_qualified=0 exception_coverage=not_checked exception_permission=0} {
            if {[string first $field $result]<0} {error "$name missing observation $field"}
        }
    } elseif {!$rc || [string first $expected $result]<0} {
        error "$name wrong rejection: rc=$rc result=$result expected=$expected"
    }
    incr ::passed
    puts "PASS $name [expr {$rc ? "rejected={$result}" : "complete_production_audit"}]"
}
expect_audit healthy_pll250 {} PASS
expect_audit healthy_legacy_clock_profile {} PASS {u_rgmii 0 0 0 0 1}
expect_audit shared_original_external_consumer {
    add_cell outside/resetConsumer LUT1 2'h2
    add_pin outside/resetConsumer I0 rawReset
} PASS
expect_audit one_oddr_delayed {dict set ::conn u_rgmii/oddr0/RST fabricReset} {ODDR mode/C/SR mismatch}
expect_audit all_oddr_delayed {
    for {set i 0} {$i<6} {incr i} {dict set ::conn u_rgmii/oddr$i/RST fabricReset}
} {Startup ODDR SR must remain original RAW reset}
expect_audit one_oddr_other_reset {
    dict set ::db net unrelated [dict create NAME unrelated TYPE SIGNAL]
    dict set ::conn u_rgmii/oddr3/RST unrelated
} {ODDR mode/C/SR mismatch}
expect_audit low_payload_old_reset {dict set ::conn u_rgmii/low0/CLR rawReset} {Role 0 lacks a unique}
expect_audit high_payload_old_reset {dict set ::conn u_rgmii/high0/CLR rawReset} {Role 0 lacks a unique}
expect_audit previous_old_reset {dict set ::conn u_rgmii/previous/CLR rawReset} {Unproved FF clock/reset/INIT}
expect_audit phase_old_reset {dict set ::conn u_rgmii/phase/PRE rawReset} {Require one actual preset-high}
expect_audit outside_fabric_consumer {
    add_cell outside/resetConsumer LUT1 2'h2
    add_pin outside/resetConsumer I0 fabricReset
} {Startup fabric reset has outside consumer}
expect_audit prefix_collision_fabric_consumer {
    add_cell u_rgmiievil/resetConsumer LUT1 2'h2
    add_pin u_rgmiievil/resetConsumer I0 fabricReset
} {Startup fabric reset has outside consumer}
expect_audit extra_internal_fabric_consumer {
    add_cell u_rgmii/extra LUT1 2'h2
    add_pin u_rgmii/extra I0 fabricReset
} {Startup reset fanout mismatch}
expect_audit extra_internal_original_consumer {
    add_cell u_rgmii/extra LUT1 2'h2
    add_pin u_rgmii/extra I0 rawReset
} {Startup reset fanout mismatch}
expect_audit extra_falling_state {ff u_rgmii/extra extraQ ground power 1 0 fabricReset} {Unaccounted falling-PAD serializer FF role}
expect_audit two_raw_hold_stages {
    ff u_rgmii/hold2 secondReset ground power 0 1 fabricReset
    dict set ::conn u_rgmii/hold2/C raw
    foreach c {u_rgmii/phase u_rgmii/previous u_rgmii/low0 u_rgmii/high0} {
        set rp [expr {$c eq "u_rgmii/phase" ? "PRE" : "CLR"}]
        dict set ::conn $c/$rp secondReset
    }
} {Require one actual preset-high}
expect_audit functional_inverted_d {dict set ::db pin u_rgmii/low0/D IS_INVERTED 1} {Startup functional FF D/CE inversion}
expect_audit functional_inverted_ce {dict set ::db pin u_rgmii/high0/CE IS_INVERTED 1} {Startup functional FF D/CE inversion}
expect_audit functional_missing_polarity {dict unset ::db pin u_rgmii/low0/D IS_INVERTED} {missing property pin}
expect_audit wrong_preset {dict set ::db cell u_rgmii/phase INIT 0} {Require one actual preset-high}
expect_audit wrong_saved_edge {dict set ::db pin u_rgmii/high0/C IS_INVERTED 0} {Role 0 lacks a unique}
expect_audit forbidden_t1 {} {PLL250/startup qualified only} {u_rgmii 1 0 0 1 1}
expect_audit forbidden_selected_half {} {PLL250/startup qualified only} {u_rgmii 0 1 0 1 1}
expect_audit startup_off_rejects_split_reset {} {Require one actual preset-high} {u_rgmii 0 0 0 0 0}
# Retain all historical default-off serializer profile equation tests. Clock
# topology is deliberately mocked here, so these are not PLL/OFF clock tests.
foreach t1 {0 1} {
    foreach selected {0 1} {
        fixture $t1 $selected
        set result [valence_mac_roles::audit u_rgmii $t1 $selected]
        if {![string match PASS_MAC_ROLE_SEMANTICS* $result] || [string first startup=0 $result]<0} {error "Default-off profile failed"}
        incr passed
        puts "PASS default_off_profile t1=$t1 selected=$selected complete_production_audit"
    }
}
puts "PASS_STARTUP_WHOLE_AUDIT_MOCKS count=$passed vendor_executed=0 clock_topology_mocked=1 serializer_equations_mocked=0 timing_qualified=0"
