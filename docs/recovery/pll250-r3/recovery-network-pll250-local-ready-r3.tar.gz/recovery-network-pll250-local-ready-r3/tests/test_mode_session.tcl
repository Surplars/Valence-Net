# Commands below are explicit mocks. No vendor process is loaded or launched.
lassign $argv root python collector
if {$collector eq ""} {set collector scripts}
set design {};set part xczu15eg-ffvb1156-2-i
proc current_design {} {return $::design}
proc get_property {key object} {if {$key in {NAME TOP}} {return $object};if {$key eq "PART"} {return $::part};error "Unsupported mock property"}
proc version {args} {return MOCK_NO_VENDOR}
proc read_verilog {args} {}
proc synth_design {args} {set ::design soc_top_observed_native_ddr}
proc open_checkpoint {args} {set ::design soc_top_observed_native_ddr}
proc close_design {} {set ::design {}}
proc write_checkpoint {path} {set f [open $path w];puts $f MOCK_NOT_A_VENDOR_DCP;close $f}
source [file join $root $collector native_network_mode.tcl]
valence_network_mode::load $root $python 1 1
rename valence_mac_roles::audit valence_mac_roles::production_audit
proc valence_mac_roles::audit {args} {return MOCK_STRUCTURAL_AUDIT_ONLY}
set passed 0
if {![catch {valence_native_mac_assert_mode}]} {error "Unconsumed design passed"};incr passed
valence_network_read_added_sources
valence_network_synth_design -flatten_hierarchy none
valence_native_mac_assert_mode;incr passed
set part wrong_part
if {![catch {valence_native_mac_assert_mode}]} {error "Wrong part passed"};incr passed
set part xczu15eg-ffvb1156-2-i
set dcp [file join $root mock-checkpoint.dcp]
valence_network_write_checkpoint $dcp;incr passed
open_checkpoint $dcp
if {![catch {valence_native_mac_assert_mode}]} {error "Raw unverified reopen passed"};incr passed
valence_network_open_checkpoint $dcp;valence_native_mac_assert_mode;incr passed
close_design
if {![catch {valence_native_mac_assert_mode}]} {error "Closed design passed"};incr passed
set f [open $dcp a];puts $f MUTATED;close $f
if {![catch {valence_network_open_checkpoint $dcp}]} {error "Mutated checkpoint passed"};incr passed
valence_network_clock::configure 0 1 wrapper
if {![catch {valence_network_mode::verify}]} {error "Changed flags passed"};incr passed
puts "MODE_SESSION_MOCK_PASS cases=$passed vendor_executed=0 structural_audit_mocked=1"
