source [file join [file dirname [info script]] typed_mock.tcl]
source [file join [file dirname [info script]] .. scripts native_network_topology.tcl]
source [file join [file dirname [info script]] .. scripts native_network_reset_timing.tcl]
add_cell launch FDPE
add_pin launch C raw;add_pin launch Q reset OUT
add_cell sink FDCE;add_pin sink CLR reset
set pathProps [dict create STARTPOINT_PIN launch/Q ENDPOINT_PIN sink/CLR SLACK 0.2 EXCEPTION {} REQUIREMENT 2.0]
set emptyDelay {};set duplicate 0
rename get_property typed_get_property
proc get_property {key objects} {
 if {$objects eq "@timing:path"} {return [dict get $::pathProps $key]}
 return [typed_get_property $key $objects]
}
proc list_property {path} {return [dict keys $::pathProps]}
proc get_timing_paths {args} {
 set delay [lindex $args [expr {[lsearch -exact $args -delay_type]+1}]]
 if {$delay eq $::emptyDelay} {return {}}
 if {$::duplicate} {return {@timing:path @timing:path}}
 return @timing:path
}
proc report_timing {args} {
 set f [open [lindex $args end] w];puts $f "MOCK QUERY RECEIPT ONLY; no timing execution";close $f
}
set tmp [file join [file dirname [info script]] reset-query-tmp-[pid]];file mkdir $tmp
set f [open [file join $tmp coverage.tsv] w]
set passed 0
proc test_pair {label mutation good} {
 global pathProps emptyDelay duplicate passed tmp f
 set pathProps [dict create STARTPOINT_PIN launch/Q ENDPOINT_PIN sink/CLR SLACK 0.2 EXCEPTION {} REQUIREMENT 2.0]
 set emptyDelay {};set duplicate 0
 eval $mutation
 set failed [catch {valence_network_reset_timing::pair launch/Q sink/CLR $label $tmp $f} why]
 if {$failed==$good} {error "Unexpected pair result $label: $why"}
 incr passed;puts "PASS $label rejected=$failed"
}
test_pair exact_Q {} 1
test_pair exact_same_FF_C {dict set pathProps STARTPOINT_PIN launch/C} 1
test_pair absent_max {set emptyDelay max} 0
test_pair absent_min {set emptyDelay min} 0
test_pair wrong_start {dict set pathProps STARTPOINT_PIN other/C} 0
test_pair wrong_end {dict set pathProps ENDPOINT_PIN other/CLR} 0
test_pair excepted {dict set pathProps EXCEPTION false_path} 0
test_pair missing_exception_property {dict unset pathProps EXCEPTION} 0
test_pair infinite_slack {dict set pathProps SLACK Inf} 0
test_pair nan_slack {dict set pathProps SLACK NaN} 0
test_pair infinite_requirement {dict set pathProps REQUIREMENT Inf} 0
test_pair nan_requirement {dict set pathProps REQUIREMENT NaN} 0
test_pair negative_slack {dict set pathProps SLACK -0.001} 0
test_pair duplicate_paths {set duplicate 1} 0
close $f
file delete -force $tmp
puts "RESET_TIMING_QUERY_MOCK_PASS cases=$passed vendor_executed=0"
