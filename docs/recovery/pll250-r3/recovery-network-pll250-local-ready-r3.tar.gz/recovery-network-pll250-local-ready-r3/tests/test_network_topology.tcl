# Finite strict-typed collector test. This models queries, NOT silicon/timing.
source [file join [file dirname [info script]] typed_mock.tcl]
source [file join [file dirname [info script]] .. scripts native_network_topology.tcl]
proc clock_net {net period fall} {
 global db clocks
 dict set clocks $net ${net}clock
 dict set db clock ${net}clock [dict create NAME ${net}clock PERIOD $period WAVEFORM [list 0 $fall]]
}
proc topology_fixture {p s layout {mapped 0}} {
 global db conn clocks pinCells netOverrides pinOverrides
 set db {}; set conn {}; set clocks {}; set pinCells {}; set netOverrides {}; set pinOverrides {}
 dict set db net power [dict create NAME power TYPE POWER]
 dict set db net ground [dict create NAME ground TYPE GROUND]
 valence_network_clock::configure $p $s $layout
 set f [valence_network_clock::facts];set root [dict get $f root];set pll [dict get $f pll];set raw [dict get $f raw];set pad [dict get $f pad];set delay [dict get $f delay]
 # Only real module-interface pins. Never synthesize enabled/<port> mock pins.
 foreach {pin net direction} {ui_clock ui IN cold_reset cold IN tx_source raw OUT tx_forward_source raw OUT tx_pad_source pad OUT delay_source ref OUT locked qualified OUT} {add_pin network_clock $pin $net $direction}
 add_cell $pll PLLE4_ADV
 foreach {key value} {CLKIN_PERIOD 4 CLKFBOUT_MULT 4 DIVCLK_DIVIDE 1 CLKOUT0_DIVIDE 2 CLKOUT1_DIVIDE 4 CLKOUT0_PHASE 0 CLKOUT1_PHASE 0 CLKOUT0_DUTY_CYCLE 0.5 CLKOUT1_DUTY_CYCLE 0.5 COMPENSATION AUTO} {dict set db cell $pll $key $value}
 foreach {pin net direction} {CLKIN ui IN RST cold IN PWRDWN ground IN CLKFBIN feedback IN CLKFBOUT feedback OUT CLKOUT0 refPll OUT CLKOUT1 padPll OUT LOCKED lock OUT} {add_pin $pll $pin $net $direction}
 foreach {net period fall} {ui 4 2 refPll 2 1 ref 2 1 padPll 4 2 pad 4 2 raw 8 4} {clock_net $net $period $fall}
 foreach {cell input output} [list $delay refPll ref] {
  add_cell $cell [expr {$mapped ? "BUFGCE" : "BUFG"}];add_pin $cell I $input;add_pin $cell O $output OUT
  if {$mapped} {add_pin $cell CE power}
 }
 if {$p} {
  add_cell $pad [expr {$mapped ? "BUFGCE" : "BUFG"}];add_pin $pad I padPll;add_pin $pad O pad OUT
  if {$mapped} {add_pin $pad CE power}
 } else {
  add_cell $pad BUFGCE_DIV;dict set db cell $pad BUFGCE_DIVIDE 2
  foreach {pin net} {I ref CE power CLR phase1 O pad} {add_pin $pad $pin $net [expr {$pin eq "O" ? "OUT" : "IN"}]}
 }
 add_cell $raw BUFGCE_DIV;dict set db cell $raw BUFGCE_DIVIDE [expr {$p ? 2 : 4}]
 foreach {pin net} [list I [expr {$p ? "padPll" : "ref"}] CE power CLR phase1 O raw] {add_pin $raw $pin $net [expr {$pin eq "O" ? "OUT" : "IN"}]}
 for {set i 0} {$i<3} {incr i} {
  set c [format {%s[%d]} [dict get $f phase_base] $i]
  ff $c phase$i [expr {$i ? "phase[expr {$i-1}]" : "ground"}] power 0 1 inhibit
  dict set conn $c/C [expr {$p ? "pad" : "ref"}]
  dict set db cell $c ASYNC_REG TRUE
 }
 lut $root/inhibit {cold lock} inhibit 4'hB
 lut $root/qualify {lock phase2} qualified 4'h2
 return $f
}
set passed 0
proc accept {label p s layout mapped} {
 global passed
 topology_fixture $p $s $layout $mapped
 set f [valence_network_clock::audit [dict get [valence_network_clock::facts] root]]
 if {$p} {valence_pll250_clock_audit [dict get $f root]}
 incr passed; puts "PASS $label"
}
proc reject {label mutation} {
 global db conn clocks pinCells netOverrides pinOverrides passed
 set f [topology_fixture 1 1 wrapper 1]
 set root [dict get $f root];set pll [dict get $f pll];set raw [dict get $f raw];set pad [dict get $f pad];set delay [dict get $f delay]
 set b [dict get $f phase_base]
 eval $mutation
 if {![catch {valence_pll250_clock_audit $root} why]} {error "NEGATIVE ESCAPED: $label"}
 incr passed;puts "REJECT $label: $why"
}
foreach {p s l} {0 0 original 0 0 wrapper 0 1 wrapper 1 0 wrapper 1 1 wrapper} {
 foreach mapped {0 1} {accept "$p/$s/$l/mapped$mapped" $p $s $l $mapped}
}
reject pad_ref500 {dict set conn $pad/I refPll}
reject raw_from_buffer {dict set conn $raw/I pad}
reject raw_wrong_divide {dict set db cell $raw BUFGCE_DIVIDE 4}
reject pll_wrong_divide {dict set db cell $pll CLKOUT1_DIVIDE 2}
reject pll_wrong_phase {dict set db cell $pll CLKOUT1_PHASE 90}
reject ref_moved {dict set conn $delay/I padPll}
reject raw_dynamic_ce {dict set conn $raw/CE lock}
reject pad_dynamic_ce {dict set conn $pad/CE lock}
reject inverted_raw_ce {dict set db pin $raw/CE IS_INVERTED 1}
reject inverted_raw_clr {dict set db pin $raw/CLR IS_INVERTED 1}
reject inverted_raw_i {dict set db pin $raw/I IS_INVERTED 1}
reject missing_pad_polarity {dict unset db pin $pad/I IS_INVERTED}
reject phase_wrong_clock {dict set conn [format {%s[1]/C} $b] padPll}
reject phase_early_clr {dict set conn $raw/CLR phase0}
reject phase_late_clr {dict set conn $raw/CLR phase2}
reject phase_extra_stage0_load {add_cell bad FDCE;add_pin bad D phase0}
reject phase_extra_stage1_load {add_cell bad FDCE;add_pin bad D phase1}
reject phase_wrong_init {dict set db cell [format {%s[0]} $b] INIT 1'b0}
reject phase_missing_async {dict set db cell [format {%s[0]} $b] ASYNC_REG FALSE}
reject phase_dynamic_ce {dict set conn [format {%s[2]/CE} $b] lock}
reject phase_wrong_shift {dict set conn [format {%s[2]/D} $b] phase0}
reject phase_wrong_inhibit {dict set db cell $root/inhibit INIT 4'hE}
reject lock_bypass {dict set conn network_clock/locked lock}
reject lock_wrong_stage {dict set conn $root/qualify/I1 phase1}
reject raw_waveform {dict set db clock rawclock WAVEFORM {2 6}}
reject pad_waveform {dict set db clock padclock WAVEFORM {1 3}}
reject multiple_clock {dict set clocks pad {padclock rawclock}}
reject mixed_branch {add_cell network_clock/disabled/legacy/pll PLLE4_ADV}
reject old_quarter_present {add_cell $root/quarter_div BUFGCE_DIV}
reject wrong_feedback {dict set conn $pll/CLKFBIN padPll}
reject wrong_interface {dict unset db pin network_clock/ui_clock}
reject incorrect_primitive {dict set db cell $pad REF_NAME BUFCE_LEAF}
reject phase_inverted_d {dict set db pin [format {%s[1]/D} $b] IS_INVERTED 1}
reject phase_inverted_q {dict set db pin [format {%s[1]/Q} $b] IS_INVERTED 1}
reject lut_inverted_input {dict set db pin $root/inhibit/I0 IS_INVERTED 1}
reject lut_inverted_output {dict set db pin $root/qualify/O IS_INVERTED 1}
topology_fixture 1 1 wrapper
source [file join [file dirname [info script]] .. scripts native_network_topology.tcl]
if {![dict get [valence_network_clock::facts] pll250] || ![dict get [valence_network_clock::facts] startup_align]} {error "Repeated source lost configured flags"}
valence_pll250_clock_audit network_clock/enabled
incr passed; puts "PASS repeated_source_retains_explicit_flags"
puts "NETWORK_TOPOLOGY_MOCK_PASS cases=$passed"
