from pathlib import Path
import tempfile,shutil,json,sys,subprocess,hashlib
R=Path(__file__).resolve().parents[1];W=R.parent
sys.path.insert(0,str(R/'checks'))
from install_overlay import install
from network_preflight import verify,sha,control_lemma
counts=0
with tempfile.TemporaryDirectory(prefix='network-overlay-',dir=R/'tests') as tmp:
    tmp=Path(tmp);base=tmp/'input'
    shutil.copytree(W/'recovery-grouped-native-board-handoff-r1',base)
    shutil.copy2(W/'recovery-native-postsynth-fixes-r1/scripts/native_mac_roles.tcl',base/'scripts/native_mac_roles.tcl')
    m=json.loads((base/'FINAL_SOURCE_MANIFEST.json').read_text())
    for e in m['files']:
        if e['path']=='scripts/native_mac_roles.tcl':e.update(sha256=sha(base/e['path']),bytes=(base/e['path']).stat().st_size)
    # Model a present local performance update that must survive untouched.
    sent=base/'scripts/local_performance_guard.tcl';sent.write_text('# independent local guard, preserve verbatim\n')
    m['files'].append(dict(path='scripts/local_performance_guard.tcl',bytes=sent.stat().st_size,sha256=sha(sent)))
    (base/'FINAL_SOURCE_MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
    for p,s in [(0,0),(0,1),(1,1)]:
        out=tmp/f'out-{p}-{s}';identity=install(base,out,p,s)
        verify(out,p,s);counts+=1
        assert sha(out/'scripts/local_performance_guard.tcl')==sha(sent);counts+=1
        assert sha(out/'checks/verify_handoff.py')==sha(base/'checks/verify_handoff.py');counts+=1
        subprocess.run([sys.executable,str(out/'checks/verify_handoff.py'),str(out)],check=True);counts+=1
        if (p,s)==(1,1):
            subprocess.run(['tclsh',str(R/'tests/test_mode_session.tcl'),str(out),sys.executable],check=True);counts+=1
            for profile in ['old','clean']:
                if profile=='clean':
                    for name in ['TriSpeedRgmiiTx.sv','TriSpeedManagedGmac.sv','ManagedPeripheralBank.sv','ObservedBoardSocTop.sv']:
                        shutil.copy2(W/'recovery-clean-guarded-integration-r1/emission/sv'/name,out/'rtl'/name)
                assert control_lemma(out)['reset_phase_induction_vectors']==16;counts+=1
    # Unmanifested current local collector closure is explicitly snapshotted;
    # never replaced by the obsolete root/scripts set.
    shutil.copytree(base/'scripts',base/'local-adapt-r3v')
    guard=base/'local-adapt-r3v/monitor_reset_complete_r3v.tcl'
    guard.write_text('# local-only exact reset/pruning guard\n')
    localout=tmp/'local-out'
    install(base,localout,1,1,'local-adapt-r3v');counts+=1
    assert sha(guard)==sha(localout/'local-adapt-r3v/monitor_reset_complete_r3v.tcl');counts+=1
    assert sha(base/'scripts/native_mac_roles.tcl')==sha(localout/'scripts/native_mac_roles.tcl');counts+=1
    subprocess.run([sys.executable,str(localout/'checks/verify_handoff.py'),str(localout)],check=True);counts+=1
    subprocess.run(['tclsh',str(R/'tests/test_mode_session.tcl'),str(localout),sys.executable,'local-adapt-r3v'],check=True);counts+=1
    try:install(base,tmp/'wrong-local-selection',1,1)
    except RuntimeError:counts+=1
    else:raise AssertionError('implicit obsolete script selection escaped')
    out=tmp/'out-0-0'
    try:verify(out,1,0)
    except RuntimeError:counts+=1
    else:raise AssertionError('wrong flags escaped')
    (out/'board/native_gmac_pll250_clock.sv').write_text('mutated')
    try:verify(out,0,0)
    except RuntimeError:counts+=1
    else:raise AssertionError('source mutation escaped')
    sent.write_text('unbound local modification')
    try:install(base,tmp/'rejected',1,1)
    except RuntimeError:counts+=1
    else:raise AssertionError('stale fullmanifest escaped')
print('INSTALL_AND_SOURCE_BINDING_MOCK_PASS cases='+str(counts))
