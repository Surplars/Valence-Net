"""Only r3 actual-header/temp/helper delta. No vendor or prior matrix rerun."""
from pathlib import Path
import sys,tempfile,subprocess
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'checks'))
from patch_local_runners import transform_runner,copy_required_helper,HEADER,OLD_TEMP
synth=HEADER+'''
source [file join [file dirname [info script]] require_vivado_min8.tcl]
set threads [valence_require_min8_threads]
set scripts [file join $root local-adapt-r3v]
read_verilog -sv [lsort [glob [file join $root rtl *.sv]]]
foreach name {soc_top_observed_native_ddr.sv ValenceBscanDebugPort.sv ValenceDmiCdc.sv native_gmac_divided_clock.sv native_tx_word_reset_boundary.sv native_rgmii_trispeed_quarter.sv} {read_verilog -sv [file join $root board $name]}
synth_design -top soc_top_observed_native_ddr -flatten_hierarchy none -generic {NATIVE_MAC_LOCAL_PAD_RESET_RELEASE=0 NATIVE_MAC_REGISTER_SELECTED_HALF=0}
write_checkpoint post_synth_unconstrained.dcp
'''
place=HEADER+'''
set entry [file dirname [info script]]
set scripts [file join $root local-adapt-r3v];set out [file join $root implementation]
source [file join $entry require_vivado_min8.tcl]
set threads [valence_require_min8_threads]
'''+OLD_TEMP+'''
if {[file exists $shortTemp]} {error "original fresh-temp guard"}
open_checkpoint [file join $root synthesis post_synth_unconstrained.dcp]
source [file join $scripts board_controls.tcl]
source [file join $scripts monitor_reset_absorbed_r3t.tcl]
source [file join $scripts monitor_reply_trimmed_r3v.tcl]
source [file join $scripts monitor_reset_complete_r3v.tcl]
proc valence_native_mac_assert_mode {{instance u_rgmii}} {
 global root python entry
 if {[get_property TOP [current_design]] ne "soc_top_observed_native_ddr" ||
     [get_property PART [current_design]] ne "xczu15eg-ffvb1156-2-i"} {error "Final native mode binding design identity mismatch"}
 exec $python [file join $root checks verify_handoff.py] $root
 exec $python [file join $entry verify_mac_control_source_lemma.py] $root
 set proof [valence_mac_roles::audit $instance 0 0]
 incr ::valence_native_mac_mode::audit_count
 return $proof
}
'''
count=0
with tempfile.TemporaryDirectory(prefix='r3-header-',dir=R/'tests') as tmp:
    tmp=Path(tmp).resolve();newroot=tmp/'new root';short=tmp/'new-short-temp'
    def run(name,text):return transform_runner(name,text,newroot,1,1,short)
    for name,text in [('synthesize_min8.tcl',synth),('place_min8.tcl',place)]:
        out=run(name,text)
        assert ';set deps [file normalize $deps];set raw50 [file normalize $raw50]' in out
        assert out.index('lassign $argv root deps raw50 python')<out.index('valence_network_mode::load $root $python 1 1');count+=1
        assert 'ROOT argument differs from the bound isolated input' in out;count+=1
        # Execute only exact argv/root header under Tcl, never the runner.
        header=out.split('\nsource ',1)[0]
        if name.startswith('place'):header=header.split('\nset entry ',1)[0]
        invocation='set argc 4\nset argv [list {'+str(newroot)+'} {'+str(tmp/'deps')+'} {'+str(tmp/'raw50.xci')+'} {python-wrapper unchanged}]\n'
        q=subprocess.run(['tclsh'],input=invocation+header+'\nputs "HEADER_OK $python $deps $raw50"\n',text=True,capture_output=True,check=True)
        assert 'HEADER_OK python-wrapper unchanged' in q.stdout;count+=1
        for broken in [text.replace('lassign $argv root deps raw50 python','lassign $argv root deps raw50 notpython'), text.replace('set deps [file normalize $deps]','set deps guessed'), text+HEADER]:
            try:run(name,broken)
            except (RuntimeError,ValueError):count+=1
            else:raise AssertionError('unknown/duplicate header escaped')
    out=run('place_min8.tcl',place)
    assert 'set entry [file dirname [info script]]' in out
    for line in place.splitlines():
        if 'monitor_' in line or 'verify_handoff.py' in line or 'audit_count' in line or 'get_property TOP' in line or 'get_property PART' in line:assert line in out
    count+=1
    assert OLD_TEMP not in out and 'refusing existing directory' in out;count+=1
    for broken in [place.replace('set entry [file dirname [info script]]','set entry guessed'),place.replace('source [file join $entry require_vivado_min8.tcl]','source guessed.tcl'),place.replace(OLD_TEMP,OLD_TEMP+'-unknown')]:
        try:run('place_min8.tcl',broken)
        except (RuntimeError,ValueError):count+=1
        else:raise AssertionError('unknown entry/temp escaped')
    # Reuse after generation is rejected by the generated Tcl guard as well as
    # the Python patch-time gate. Only this two-line block is executed.
    tempblock=out[out.index('set shortTemp '):].splitlines()[:2]
    short.mkdir()
    script='if {[catch {\n'+'\n'.join(tempblock)+'\n} why]} {puts "TEMP_REJECTED $why"} else {error "TEMP_ESCAPED"}\n'
    q=subprocess.run(['tclsh'],input=script,text=True,capture_output=True,check=True)
    assert 'TEMP_REJECTED Fresh isolated shortTemp required' in q.stdout;count+=1
    try:run('place_min8.tcl',place)
    except RuntimeError:count+=1
    else:raise AssertionError('existing temp escaped Python gate')
    src=tmp/'entry';dst=tmp/'new-entry';src.mkdir();dst.mkdir()
    helper=src/'require_vivado_min8.tcl';helper.write_bytes(b'# original helper bytes\r\nreturn\n')
    receipt=copy_required_helper(src,dst)
    assert helper.read_bytes()==(dst/helper.name).read_bytes() and receipt['bytes']==helper.stat().st_size and len(receipt['sha256'])==64;count+=1
    try:copy_required_helper(src,dst)
    except RuntimeError:count+=1
    else:raise AssertionError('existing helper overwritten')
print('RUNNER_R3_HEADER_TEMP_HELPER_MOCK_PASS cases='+str(count)+' vendor_executed=0 whole_local_runner_bytes_unavailable=1')
