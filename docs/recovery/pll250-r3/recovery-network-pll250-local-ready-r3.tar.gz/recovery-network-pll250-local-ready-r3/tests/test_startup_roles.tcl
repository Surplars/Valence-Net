source [file join [file dirname [info script]] .. scripts native_mac_roles.tcl]
# Mock only vendor-facing queries; execute production ff/startup_reset/startup_loads.
rename valence_mac_roles::property valence_mac_roles::saved_property
rename valence_mac_roles::net valence_mac_roles::saved_net
rename valence_mac_roles::driver valence_mac_roles::saved_driver
rename valence_mac_roles::constant valence_mac_roles::saved_constant
proc valence_mac_roles::property {kind name key} {return [dict get $::props $name $key]}
proc valence_mac_roles::net {pin} {return [dict get $::nets $pin]}
proc valence_mac_roles::driver {pin} {return [dict get $::drivers $pin]}
proc valence_mac_roles::constant {pin v} {return [expr {[dict exists $::constants $pin] && [dict get $::constants $pin] eq "$v"}]}
proc get_cells {args} {return $::cells}
proc get_property {key objects} {if {$key ne "NAME"} {error wrongquery};return $objects}
proc get_pins {args} {if {[lsearch -exact $args -leaf]>=0} {return $::loads};return [lindex $args end]}
proc get_nets {args} {return mocked_net}
proc reset {} {
 set ::cells {u_rgmii/hold}
 set ::props [dict create u_rgmii/hold [dict create REF_NAME FDPE INIT 1] u_rgmii/hold/C [dict create IS_INVERTED 0] u_rgmii/hold/PRE [dict create IS_INVERTED 0] u_rgmii/hold/Q [dict create IS_INVERTED 0] u_rgmii/hold/D [dict create IS_INVERTED 0] u_rgmii/hold/CE [dict create IS_INVERTED 0]]
 set ::nets [dict create rawpin RAW u_rgmii/hold/C RAW u_rgmii/hold/PRE ORIGINAL u_rgmii/hold/Q FABRIC]
 set ::drivers [dict create u_rgmii/hold/Q u_rgmii/hold/Q]
 set ::constants [dict create u_rgmii/hold/D 0 u_rgmii/hold/CE 1]
 set ::loads {u_rgmii/phase/PRE u_rgmii/previous/CLR u_rgmii/low/CLR outside/consumer/PRE}
}
set tests 0
proc check {name mutation expected} {
 reset;uplevel #0 $mutation
 set rc [catch {valence_mac_roles::startup_reset u_rgmii rawpin ORIGINAL} msg]
 if {$expected eq "PASS"} {if {$rc || $msg ne {hold u_rgmii/hold fabric FABRIC}} {error "$name unexpectedly failed: $msg"}} else {
  if {!$rc || [string first $expected $msg]<0} {error "$name wrong rejection: $rc $msg"}
 }
 incr ::tests;puts "PASS $name"
}
check healthy {} PASS
foreach {name mutation} {
 wrongtype {dict set ::props u_rgmii/hold REF_NAME FDCE}
 wronginit {dict set ::props u_rgmii/hold INIT 0}
 wrongclock {dict set ::nets u_rgmii/hold/C PAD}
 invertedclock {dict set ::props u_rgmii/hold/C IS_INVERTED 1}
 invertedpre {dict set ::props u_rgmii/hold/PRE IS_INVERTED 1}
 wrongpre {dict set ::nets u_rgmii/hold/PRE OTHER}
 feedbackpre {dict set ::nets u_rgmii/hold/PRE FABRIC}
 cedisabled {dict set ::constants u_rgmii/hold/CE 0}
 cedynamic {dict unset ::constants u_rgmii/hold/CE}
 dnonzero {dict set ::constants u_rgmii/hold/D 1}
 ddynamic {dict unset ::constants u_rgmii/hold/D}
 missing {set ::cells {}}
 duplicated {lappend ::cells u_rgmii/hold}
} {check $name $mutation {Require one exact RAW startup hold FF}}
check invertedq {dict set ::props u_rgmii/hold/Q IS_INVERTED 1} {Startup hold Q driver/polarity mismatch}
check indirectq {dict set ::drivers u_rgmii/hold/Q inverter/O} {Startup hold Q driver/polarity mismatch}
check samereset {dict set ::nets u_rgmii/hold/Q ORIGINAL} {Startup fabric and ODDR resets must differ}
check invertedD {dict set ::props u_rgmii/hold/D IS_INVERTED 1} {Startup hold D/CE inversion}
check invertedCE {dict set ::props u_rgmii/hold/CE IS_INVERTED 1} {Startup hold D/CE inversion}
reset
valence_mac_roles::startup_loads u_rgmii u_rgmii/hold/Q {u_rgmii/phase/PRE u_rgmii/previous/CLR u_rgmii/low/CLR} 1
incr tests;puts {PASS exact_loads_external_consumers_ignored}
foreach {name mutation} {
 extra {lappend ::loads u_rgmii/extra/CLR}
 missing {set ::loads {u_rgmii/phase/PRE u_rgmii/previous/CLR}}
 duplicate {lappend ::loads u_rgmii/low/CLR}
 wrongpin {set ::loads {u_rgmii/phase/CLR u_rgmii/previous/CLR u_rgmii/low/CLR}}
} {
 reset;set ::loads [lrange $::loads 0 2];eval $mutation
 set rc [catch {valence_mac_roles::startup_loads u_rgmii u_rgmii/hold/Q {u_rgmii/phase/PRE u_rgmii/previous/CLR u_rgmii/low/CLR}} msg]
 if {!$rc || [string first {Startup reset fanout mismatch} $msg]<0} {error "load_$name wrong rejection $msg"}
 incr tests;puts "PASS load_$name"
}
reset
set rc [catch {valence_mac_roles::startup_loads u_rgmii u_rgmii/hold/Q {u_rgmii/phase/PRE u_rgmii/previous/CLR u_rgmii/low/CLR}} msg]
if {!$rc || [string first {Startup fabric reset has outside consumer} $msg]<0} {error "outside fabric sink not rejected"}
incr tests;puts {PASS outside_fabric_consumer}
foreach args {{u_rgmii 0 0 0 2 0} {u_rgmii 0 0 0 0 2} {u_rgmii 1 0 0 0 1} {u_rgmii 0 1 0 1 0}} {
 set rc [catch {valence_mac_roles::audit {*}$args} msg]
 if {!$rc || (![string match {Explicit startup/PLL250*} $msg] && ![string match {PLL250/startup qualified*} $msg])} {error "mode rejection failed $msg"}
 incr tests;puts "PASS mode $args"
}
puts "PASS_STARTUP_ROLE_MOCKS count=$tests vendor_executed=0"
