# Bounded functional-reset path coverage. No exceptions. Invoke on routed design
# after the full source-bound role audit, separately for each 10/100/1000 scenario.
namespace eval valence_network_reset_timing {}
proc valence_network_reset_timing::pair {source sink tag directory stream} {
    set a [valence_network_clock::one get_pins $source]
    set b [valence_network_clock::one get_pins $sink]
    # Timing paths can name launch C (ordinary STA) rather than requested Q.
    # Accept only that SAME proved FF's C or Q; never an unrelated alias.
    set launch [file dirname $source]/C
    set cell [valence_network_clock::one get_cells [file dirname $source]]
    if {[get_property REF_NAME $cell] ni {FDPE FDCE} || [file tail $source] ne "Q"} {error "Functional reset launch must be exact FF Q: $source"}
    valence_network_clock::one get_pins $launch
    foreach delay {max min} {
        set paths [get_timing_paths -quiet -from $a -to $b -delay_type $delay -nworst 1 -max_paths 1]
        if {[llength $paths]!=1} {error "Missing/excepted functional reset $delay path: $source -> $sink"}
        set p [lindex $paths 0]
        foreach property {STARTPOINT_PIN ENDPOINT_PIN SLACK EXCEPTION REQUIREMENT} {
            if {$property ni [list_property $p]} {error "Missing timing path property: $property"}
        }
        set actualStart [get_property STARTPOINT_PIN $p];set actualEnd [get_property ENDPOINT_PIN $p]
        set slack [get_property SLACK $p];set exception [get_property EXCEPTION $p]
        set requirement [get_property REQUIREMENT $p]
        if {$actualStart ni [list $source $launch] || $actualEnd ne $sink || $exception ne "" ||
            ![string is double -strict $slack] || ![string is double -strict $requirement] ||
            [string match -nocase *inf* $slack] || [string match -nocase *nan* $slack] ||
            [string match -nocase *inf* $requirement] || [string match -nocase *nan* $requirement]} {
            error "Uncovered/excepted/nonfinite functional reset path: $source -> $sink ($delay)"
        }
        report_timing -from $a -to $b -delay_type $delay -max_paths 1 -nworst 1 -input_pins -file [file join $directory $tag-$delay.rpt]
        puts $stream [join [list $tag $delay $source $sink $actualStart $actualEnd $requirement $slack $exception] "\t"]
        flush $stream
        if {$slack < 0} {error "Functional reset recovery/removal fails: $source -> $sink $delay slack=$slack"}
    }
}
proc valence_network_reset_timing::collect {hier directory} {
    set f [valence_network_clock::facts]
    # Full equations and split-reset fanout are re-proved for the current design.
    valence_native_mac_assert_mode $hier
    valence_network_clock::audit [dict get $f root]
    if {[file exists $directory]} {error "Fresh functional-reset report directory required"}
    file mkdir $directory
    set pairs {}
    set phase [format {%s[1]/Q} [dict get $f phase_base]]
    lappend pairs [list $phase [dict get $f raw]/CLR phase_raw]
    if {![dict get $f pll250]} {lappend pairs [list $phase [dict get $f pad]/CLR phase_pad]}
    set common [valence_network_clock::driver $hier/tx_pad_reset]
    set oddrs [concat $::valence_mac_roles::last_lanes $::valence_mac_roles::last_clock]
    if {[llength $oddrs]!=6 || [llength [lsort -unique $oddrs]]!=6} {error "Reset timing requires all six proved ODDR cells"}
    set index 0
    foreach c $oddrs {lappend pairs [list $common $c/RST common_oddr$index];incr index}
    if {[dict get $f startup_align]} {
        set clocks [valence_mac_roles::clocks $hier 0 [dict get $f pll250]]
        set hold [dict get [valence_mac_roles::startup_reset $hier [dict get $clocks raw_pin] [valence_mac_roles::net $hier/tx_pad_reset]] hold]
        lappend pairs [list $common $hold/PRE common_hold]
        set loads [get_property NAME [get_pins -quiet -leaf -of_objects [get_nets -quiet -segments -of_objects [valence_network_clock::one get_pins $hold/Q]] -filter {DIRECTION == IN}]]
        # Finite bound includes every direct functional fabric async pin. Role
        # audit already proved exact membership, including merged control banks.
        if {[llength $loads]<2 || [llength $loads]>14} {error "Unbounded/missing serializer fabric reset fanout"}
        set index 0
        foreach pin [lsort $loads] {
            if {[file tail $pin] ni {PRE CLR}} {error "Non-reset fabric hold sink"}
            lappend pairs [list $hold/Q $pin fabric$index];incr index
        }
    } else {
        # Baseline/OFF uses the same original word-reset source for all fabric
        # state. Include these arcs as well, not only the six ODDR SR pins.
        set loads [get_property NAME [get_pins -quiet -leaf -of_objects [get_nets -quiet -segments -of_objects [valence_network_clock::one get_pins $common]] -filter {DIRECTION == IN}]]
        set fabric {}
        foreach pin $loads {
            if {[string first "$hier/" $pin]==0 && [file tail $pin] in {PRE CLR}} {lappend fabric $pin}
        }
        if {[llength $fabric]<2 || [llength $fabric]>14} {error "Unbounded/missing OFF fabric reset fanout"}
        set index 0
        foreach pin [lsort $fabric] {lappend pairs [list $common $pin common_fabric$index];incr index}
    }
    set stream [open [file join $directory coverage.tsv] {WRONLY CREAT EXCL}]
    puts $stream "tag\tdelay\tsource\tsink\tactual_start\tactual_end\trequirement_ns\tslack_ns\texception"
    try {
        foreach p $pairs {lassign $p source sink tag;pair $source $sink $tag $directory $stream}
        puts "FUNCTIONAL_RESET_TIMING_COVERAGE_PASS pairs=[llength $pairs] both_max_min=1 reports=$directory"
    } finally {close $stream}
    return [llength $pairs]
}
