# Actual assembled board clock-source gate. No timing exceptions.
proc native_same_net {a b} {
 set aa [get_pins -quiet $a];set bb [get_pins -quiet $b]
 if {[llength $aa]!=1 || [llength $bb]!=1} {error "Missing clock ancestry pin $a/$b"}
 set an [get_nets -segments -of_objects $aa];set bn [get_nets -segments -of_objects $bb]
 foreach n $an {if {[lsearch -exact $bn $n]>=0} {return}}
 error "Clock ancestry net mismatch $a/$b"
}
proc native_clock_ancestry {} {
 set topology [valence_network_clock::facts]
 set raw [dict get $topology raw]; set pad [dict get $topology pad]
 set gate u_soc/nativeBank/uart/gatedClock_gate/buffer
 if {[get_property REF_NAME [get_cells -quiet $gate]] ne "BUFGCE"} {error "UART managed clock gate changed"}
 native_same_net aon_clock_buffer/I $gate/I
 native_same_net aon_clock_buffer/I u_soc/io_uartGateClockSource
 native_same_net aon_clock_buffer/O u_soc/io_alwaysOnClock
 set driver [get_pins -leaf -of_objects [get_nets -segments -of_objects [get_pins aon_clock_buffer/I]] -filter {DIRECTION == OUT}]
 if {[llength $driver]!=1 || [get_property REF_PIN_NAME $driver] ne "CLKOUT1" || [get_property REF_NAME [get_cells -of_objects $driver]] ne "MMCME4_ADV"} {error "Raw50 is not the direct actual MMCM CLKOUT1"}
 set mmcm [get_cells -of_objects $driver]
 foreach {property value} {DIVCLK_DIVIDE 1 CLKFBOUT_MULT_F 5 CLKOUT0_DIVIDE_F 12.5 CLKOUT1_DIVIDE 25 CLKOUT2_DIVIDE 10 CLKIN1_PERIOD 4 CLKOUT0_PHASE 0 CLKOUT1_PHASE 0 CLKOUT2_PHASE 0} {
  if {abs([get_property $property $mmcm]-$value)>0.001} {error "Actual MMCM mismatch $property"}
 }
 foreach {pin period} [list u_soc/clock 10 aon_clock_buffer/O 20 $gate/O 20 $raw/O 8 $pad/O 4] {
  set c [get_clocks -of_objects [get_pins $pin]]
  if {[llength $c]!=1 || abs([get_property PERIOD $c]-$period)>0.001} {error "Actual clock period mismatch $pin"}
 }
 # Exact configured physical RAW source, still shared by complete packet owners.
 native_same_net $raw/O u_soc/nativeBank/gmac/txManaged_gate/buffer/I
 native_same_net $raw/O u_soc/nativeBank/gmac/rxManaged_gate/buffer/I
 valence_quarter_tx_clocks network_clock
 puts "NATIVE_BOARD_CLOCK_ANCESTRY_PASS CPU100 RAW50_SIBLING_UART BOARD_PLL_DIV_GMAC"
}
