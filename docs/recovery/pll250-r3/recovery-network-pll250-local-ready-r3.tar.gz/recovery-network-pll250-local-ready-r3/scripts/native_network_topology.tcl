# Read-only, topology-aware network-clock proof. No timing exceptions or clock
# synthesis/latency substitutions. Missing names/properties fail closed.
namespace eval valence_network_clock {
    if {![info exists pll250]} {variable pll250 0}
    if {![info exists startup_align]} {variable startup_align 0}
    if {![info exists layout]} {variable layout original}
}
proc valence_network_clock::configure {p s l} {
    if {$p ni {0 1} || $s ni {0 1} || $l ni {original wrapper} || ($p && $l ne "wrapper")} {
        error "Explicit network topology requires Boolean knobs and original/wrapper layout"
    }
    variable pll250 $p; variable startup_align $s; variable layout $l
}
proc valence_network_clock::facts {} {
    variable pll250; variable startup_align; variable layout
    set root network_clock
    if {$layout eq "wrapper"} {set root [expr {$pll250 ? "network_clock/enabled" : "network_clock/disabled/legacy"}]}
    set pad [expr {$pll250 ? "$root/pad_buffer" : "$root/quarter_div"}]
    return [dict create root $root interface network_clock pll $root/pll raw $root/raw_div pad $pad delay $root/delay_buffer \
        phase_base $root/phase_reset_reg pll250 $pll250 startup_align $startup_align layout $layout]
}
proc valence_network_clock::one {command name} {
    set objects [$command -quiet $name]
    if {[llength $objects]!=1 || [get_property NAME $objects] ne $name} {error "Exact network object required: $command $name ($objects)"}
    return $objects
}
proc valence_network_clock::prop {command name key} {return [get_property $key [one $command $name]]}
proc valence_network_clock::bit {value expected} {
    if {$expected} {return [expr {$value in {1 TRUE true 1'b1}}]}
    return [expr {$value in {0 FALSE false 1'b0}}]
}
proc valence_network_clock::net {pin} {
    set ns [get_nets -quiet -segments -of_objects [one get_pins $pin]]
    if {![llength $ns]} {error "Disconnected network pin: $pin"}
    return [lindex [lsort [get_property NAME $ns]] 0]
}
proc valence_network_clock::same {a b} {
    if {[net $a] ne [net $b]} {error "Network net mismatch: $a / $b"}
}
proc valence_network_clock::driver {pin} {
    set ps [get_pins -quiet -leaf -of_objects [get_nets -quiet -segments -of_objects [one get_pins $pin]] -filter {DIRECTION == OUT}]
    if {[llength $ps]!=1} {error "Network direct driver missing/ambiguous: $pin ($ps)"}
    return [get_property NAME $ps]
}
proc valence_network_clock::driven {pin output} {
    one get_pins $output
    if {[driver $pin] ne $output} {error "Wrong network direct driver: $pin expected $output"}
}
proc valence_network_clock::constant {pin value} {
    if {[prop get_nets [net $pin] TYPE] ne ($value ? "POWER" : "GROUND")} {error "Network constant changed: $pin expected $value"}
}
proc valence_network_clock::noninverted {pin} {
    if {![bit [prop get_pins $pin IS_INVERTED] 0]} {error "Network pin polarity missing/inverted: $pin"}
}
proc valence_network_clock::number {cell key expected} {
    set actual [prop get_cells $cell $key]
    if {![string is double -strict $actual] || abs($actual-$expected)>0.001} {error "Network property mismatch: $cell $key=$actual expected $expected"}
}
proc valence_network_clock::wave {pin period fall} {
    set clocks [get_clocks -quiet -of_objects [one get_pins $pin]]
    if {[llength $clocks]!=1} {error "Network clock not unique: $pin"}
    set p [get_property PERIOD $clocks]; set w [get_property WAVEFORM $clocks]
    if {[llength $w]!=2 || ![string is double -strict $p]} {error "Missing network waveform: $pin"}
    lassign $w rise end
    if {![string is double -strict $rise] || ![string is double -strict $end] || abs($p-$period)>0.001 || abs($rise)>0.001 || abs($end-$fall)>0.001} {
        error "Network actual waveform mismatch: $pin period=$p waveform=$w expected=0,$fall/$period"
    }
    return $clocks
}
# BUFG is sometimes mapped to BUFGCE. Accept that only when its real CE is
# tied high and both pins are explicitly noninverting, never a dynamic gate.
proc valence_network_clock::ungated {cell source} {
    set ref [prop get_cells $cell REF_NAME]
    if {$ref ni {BUFG BUFGCE}} {error "Not an unconditional network clock buffer: $cell ($ref)"}
    noninverted $cell/I
    if {$ref eq "BUFGCE"} {noninverted $cell/CE; constant $cell/CE 1}
    driven $cell/I $source
}
# Small exact combinational truth proof for inhibit and qualified-lock logic.
# Only constants, named variables and bounded INV/LUT cones are admitted.
proc valence_network_clock::value {pin assignment {seen {}}} {
    set n [net $pin]
    if {[dict exists $assignment $n]} {return [dict get $assignment $n]}
    set type [prop get_nets $n TYPE]
    if {$type eq "POWER"} {return 1}; if {$type eq "GROUND"} {return 0}
    if {[llength $seen]>=8 || $n in $seen} {error "Unbounded/cyclic network lock cone"}
    lappend seen $n
    set output [driver $pin]; noninverted $output
    set c [file dirname $output]; set ref [prop get_cells $c REF_NAME]
    if {$ref eq "INV"} {noninverted $c/I; return [expr {1-[value $c/I $assignment $seen]}]}
    if {![regexp {^LUT([1-6])$} $ref -> width]} {error "Unsupported network lock cone leaf: $output ($ref)"}
    set init [prop get_cells $c INIT]
    if {![regexp {^([0-9]+)'([hHbB])([0-9a-fA-F]+)$} $init -> bits radix digits] || $bits != (1<<$width)} {error "Malformed network LUT INIT: $c"}
    if {[string tolower $radix] eq "h"} {set table [expr 0x$digits]} else {
        if {![regexp {^[01]+$} $digits]} {error "Nonbinary network LUT"}; set table [expr 0b$digits]
    }
    if {$table >= (1<<$bits)} {error "Oversized network LUT INIT"}
    set index 0
    for {set i 0} {$i<$width} {incr i} {noninverted $c/I$i; set index [expr {$index | ([value $c/I$i $assignment $seen]<<$i)}]}
    return [expr {($table>>$index)&1}]
}
proc valence_network_clock::logic {output a b table} {
    if {[net $a] eq [net $b]} {error "Network Boolean inputs unexpectedly alias"}
    for {set index 0} {$index<4} {incr index} {
        set assignment [dict create [net $a] [expr {$index&1}] [net $b] [expr {($index>>1)&1}]]
        if {[value $output $assignment] != (($table>>$index)&1)} {error "Network Boolean equation mismatch: $output vector=$index"}
    }
}
proc valence_network_clock::phase_audit {f} {
    set root [dict get $f interface]; set base [dict get $f phase_base]; set pll [dict get $f pll]
    set phase_clock [expr {[dict get $f pll250] ? "[dict get $f pad]/O" : "[dict get $f delay]/O"}]
    for {set i 0} {$i<3} {incr i} {
        set c [format {%s[%d]} $base $i]
        if {[prop get_cells $c REF_NAME] ne "FDPE" || ![bit [prop get_cells $c INIT] 1] || ![bit [prop get_cells $c ASYNC_REG] 1]} {error "Unproved network phase FF: $c"}
        foreach p {C PRE CE D Q} {noninverted $c/$p}
        constant $c/CE 1; driven $c/C $phase_clock
        logic $c/PRE $root/cold_reset $pll/LOCKED 11
        if {$i==0} {constant $c/D 0} else {driven $c/D [format {%s[%d]/Q} $base [expr {$i-1}]]}
        if {$i<2} {
            set sinks [get_property NAME [get_pins -quiet -leaf -of_objects [get_nets -quiet -segments -of_objects [one get_pins $c/Q]] -filter {DIRECTION == IN}]]
            set expected [list [format {%s[%d]/D} $base [expr {$i+1}]]]
            if {$i==1} {
                lappend expected [dict get $f raw]/CLR
                if {![dict get $f pll250]} {lappend expected [dict get $f pad]/CLR}
            }
            if {[lsort $sinks] ne [lsort $expected]} {error "Network phase early fanout differs: $c sinks=$sinks expected=$expected"}
        }
    }
    # Bit order: a=PLL LOCKED, b=phase_reset[2]. Only a=1,b=0 is locked.
    logic $root/locked $pll/LOCKED [format {%s[2]/Q} $base] 2
}
proc valence_network_clock::audit {hier} {
    set f [facts]
    if {$hier ne [dict get $f root]} {error "Clock hierarchy does not match explicit configured topology: $hier"}
    set interface [dict get $f interface]
    set pll [dict get $f pll]; set raw [dict get $f raw]; set pad [dict get $f pad]; set delay [dict get $f delay]
    if {[prop get_cells $pll REF_NAME] ne "PLLE4_ADV"} {error "Wrong network PLL primitive"}
    foreach {key value} {CLKIN_PERIOD 4 CLKFBOUT_MULT 4 DIVCLK_DIVIDE 1 CLKOUT0_DIVIDE 2 CLKOUT0_PHASE 0 CLKOUT0_DUTY_CYCLE 0.5} {number $pll $key $value}
    if {[prop get_cells $pll COMPENSATION] ne "AUTO"} {error "Network PLL compensation changed"}
    foreach p {CLKIN CLKFBIN RST PWRDWN} {noninverted $pll/$p}
    same $pll/CLKIN $interface/ui_clock; same $pll/RST $interface/cold_reset; driven $pll/CLKFBIN $pll/CLKFBOUT
    constant $pll/PWRDWN 0
    wave $pll/CLKIN 4 2; wave $pll/CLKOUT0 2 1
    ungated $delay $pll/CLKOUT0; wave $delay/O 2 1
    if {[prop get_cells $raw REF_NAME] ne "BUFGCE_DIV"} {error "RAW clock must remain a dedicated divider"}
    foreach p {I CE CLR} {noninverted $raw/$p}; constant $raw/CE 1
    driven $raw/CLR [format {%s[1]/Q} [dict get $f phase_base]]
    if {[dict get $f pll250]} {
        foreach {key value} {CLKOUT1_DIVIDE 4 CLKOUT1_PHASE 0 CLKOUT1_DUTY_CYCLE 0.5} {number $pll $key $value}
        number $raw BUFGCE_DIVIDE 2; wave $pll/CLKOUT1 4 2
        ungated $pad $pll/CLKOUT1; driven $raw/I $pll/CLKOUT1
        if {[llength [get_cells -quiet $hier/quarter_div]] || [llength [get_cells -quiet network_clock/disabled/legacy/pll]] || [llength [get_cells -quiet network_clock/pll]]} {error "Mixed PLL250/legacy clock branches"}
    } else {
        number $raw BUFGCE_DIVIDE 4; driven $raw/I $delay/O
        if {[prop get_cells $pad REF_NAME] ne "BUFGCE_DIV"} {error "Legacy PAD divider changed"}
        number $pad BUFGCE_DIVIDE 2; foreach p {I CE CLR} {noninverted $pad/$p}; constant $pad/CE 1
        driven $pad/I $delay/O; driven $pad/CLR [format {%s[1]/Q} [dict get $f phase_base]]
        if {[llength [get_cells -quiet network_clock/enabled/pll]] || [llength [get_cells -quiet $hier/pad_buffer]]} {error "Mixed legacy/PLL250 clock branches"}
    }
    wave $raw/O 8 4; wave $pad/O 4 2
    foreach {port output} [list tx_source $raw/O tx_forward_source $raw/O tx_pad_source $pad/O delay_source $delay/O] {driven $interface/$port $output}
    phase_audit $f
    puts "NETWORK_CLOCK_TOPOLOGY_PASS layout=[dict get $f layout] pll250=[dict get $f pll250] RAW=$raw PAD=$pad REF500=$delay functional_resets_fully_timed"
    return $f
}
proc valence_pll250_clock_audit {hier} {
    if {![dict get [valence_network_clock::facts] pll250]} {error "PLL250 audit requires explicit ON topology"}
    return [valence_network_clock::audit $hier]
}
