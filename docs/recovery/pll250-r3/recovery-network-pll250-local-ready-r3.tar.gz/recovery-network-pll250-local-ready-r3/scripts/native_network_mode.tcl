# Explicit local-runner hooks. Sourcing this file performs no vendor operation.
namespace eval valence_network_mode {
    variable ready 0
    variable consumed 0
    variable traced 0
}
proc valence_network_mode::invalidate {args} {variable consumed 0}
proc valence_network_mode::watch {} {
    variable traced
    if {$traced} {return}
    foreach command {synth_design open_checkpoint read_checkpoint close_design close_project create_project link_design} {
        if {[llength [info commands ::$command]]} {trace add execution ::$command enter ::valence_network_mode::invalidate}
    }
    set traced 1
}
proc valence_network_mode::design {} {
    set d [current_design]
    if {[llength $d]!=1 || [get_property TOP $d] ne "soc_top_observed_native_ddr" || [get_property PART $d] ne "xczu15eg-ffvb1156-2-i"} {error "Wrong exact native TOP/PART"}
    return $d
}
proc valence_network_mode::assert_session {} {
    variable consumed;variable bound_design;variable binding
    if {!$consumed || [design] ne $bound_design || [verify] ne $binding} {error "Require fresh bound synthesis or verified sealed checkpoint reopen"}
}
proc valence_network_mode::load {root python pll250 startup} {
    if {$pll250 ni {0 1} || $startup ni {0 1}} {error "Explicit Boolean network knobs required"}
    variable consumed 0
    variable directory [file normalize $root];variable interpreter $python
    variable p $pll250;variable s $startup
    exec $python [file join $directory checks verify_handoff.py] $directory
    set receipt [exec $python [file join $directory checks network_preflight.py] $directory $p $s wrapper]
    if {![string match {NETWORK_SOURCE_BINDING_PASS *} $receipt]} {error "Network source preflight failed"}
    set f [open [file join $directory NETWORK_COLLECTOR_DIR.txt] r]
    set collector_dir [string trim [read $f]];close $f
    if {$collector_dir ni {scripts local-adapt-r3v}} {error "Unsupported bound collector directory"}
    uplevel #0 [list source [file join $directory $collector_dir native_network_topology.tcl]]
    valence_network_clock::configure $p $s wrapper
    uplevel #0 [list source [file join $directory $collector_dir native_mac_roles.tcl]]
    uplevel #0 [list source [file join $directory $collector_dir native_network_reset_timing.tcl]]
    namespace eval ::valence_native_mac_mode {variable t1 0;variable selected 0;variable control_lemma 1}
    variable ready 1
    watch
    puts $receipt
}
proc valence_network_mode::verify {} {
    variable ready;variable directory;variable interpreter;variable p;variable s
    if {!$ready} {error "Load explicit source-bound network mode first"}
    set f [valence_network_clock::facts]
    if {[dict get $f pll250]!=$p || [dict get $f startup_align]!=$s || [dict get $f layout] ne "wrapper"} {error "Network collector mode changed after binding"}
    exec $interpreter [file join $directory checks verify_handoff.py] $directory
    set identity [exec $interpreter [file join $directory checks network_preflight.py] $directory $p $s wrapper]
    if {![string match {NETWORK_SOURCE_BINDING_PASS *} $identity]} {error "Network identity preflight failed"}
    return [list $p $s [lindex $identity 1]]
}
proc valence_network_generics {} {
    lassign [valence_network_mode::verify] p s
    return [list NATIVE_MAC_LOCAL_PAD_RESET_RELEASE=0 NATIVE_MAC_REGISTER_SELECTED_HALF=0 NATIVE_MAC_ENABLE_PLL250=$p NATIVE_MAC_ALIGN_PAD_STARTUP_RELEASE=$s]
}
proc valence_network_read_added_sources {} {
    valence_network_mode::verify
    read_verilog -sv [file join $::valence_network_mode::directory board native_gmac_pll250_clock.sv]
}
proc valence_native_mac_assert_mode {{instance u_rgmii}} {
    valence_network_mode::assert_session
    lassign [valence_network_mode::verify] p s
    return [valence_mac_roles::audit $instance 0 0 0 $p $s]
}
# An explicit synthesis entry, never called automatically. Existing project/IP,
# 309 RTL and old board whitelist must already be loaded; load_added_sources
# above adds ONLY the new wrapper module. No old DCP counts as consumed source.
proc valence_network_synth_design {args} {
    foreach option $args {
        if {$option in {-t -to -g -ge} || [string match -top* $option] || [string match -gen* $option]} {error "Network binding owns exact top/four generics"}
    }
    set invocation [list -top soc_top_observed_native_ddr -generic [valence_network_generics] {*}$args]
    set ::valence_network_mode::consumed 0
    synth_design {*}$invocation
    set ::valence_network_mode::bound_design [valence_network_mode::design]
    set ::valence_network_mode::binding [valence_network_mode::verify]
    set ::valence_network_mode::consumed 1
    set f [open [file join $::valence_network_mode::directory NETWORK_SYNTH_OBSERVATION.tcllist] {WRONLY CREAT EXCL}]
    puts $f [list invocation $invocation source_binding [valence_network_mode::verify] tool [version -short] part [get_property PART [current_design]]]
    close $f
}
proc valence_network_postroute {rate output} {
    if {$rate ni {10 100 1000}} {error "Explicit tri-speed scenario required"}
    valence_native_mac_assert_mode
    valence_network_reset_timing::collect u_rgmii [file join $output functional-reset-$rate]
}

# Only these explicit wrappers preserve fresh-source checkpoint provenance.
# Raw open_checkpoint invalidates consumption and cannot pass assert_mode.
proc valence_network_write_checkpoint {path} {
    valence_network_mode::assert_session
    if {[file exists $path] || [file exists $path.network.json]} {error "Fresh checkpoint/receipt paths required"}
    write_checkpoint $path
    lassign [valence_network_mode::verify] p s
    exec $::valence_network_mode::interpreter [file join $::valence_network_mode::directory checks network_checkpoint.py] seal $::valence_network_mode::directory $path $p $s
}
proc valence_network_open_checkpoint {path} {
    lassign [valence_network_mode::verify] p s
    exec $::valence_network_mode::interpreter [file join $::valence_network_mode::directory checks network_checkpoint.py] verify $::valence_network_mode::directory $path $p $s
    set ::valence_network_mode::consumed 0
    open_checkpoint $path
    set ::valence_network_mode::bound_design [valence_network_mode::design]
    set ::valence_network_mode::binding [valence_network_mode::verify]
    set ::valence_network_mode::consumed 1
    # Full role/clock audit follows only after board clocks/constraints exist.
}
