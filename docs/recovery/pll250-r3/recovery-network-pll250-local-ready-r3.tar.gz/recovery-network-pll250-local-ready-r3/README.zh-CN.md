# PLL250 + PAD 启动保持：本地源码输入补丁

状态：源码、有限功能仿真和严格查询 mock 通过；尚未运行本地 Vivado，也没有时序或器件通过结论。RTL 两个新参数默认均为0，当前 serializer 固定0/0。旧500MHz原始工程不修改，作为物理控制臂保留。

## 安装（只复制/校验源码，不启动工具）

以下 CURRENT_NATIVE 必须是当前已修正的本地完整309 RTL输入；NEW_NATIVE、NEW_ENTRY 必须不存在。

```sh
python checks/install_overlay.py CURRENT_NATIVE NEW_NATIVE --script-dir local-adapt-r3v --pll250 1 --startup-align 1
python checks/patch_local_runners.py CURRENT_ENTRY NEW_ENTRY NEW_NATIVE --pll250 1 --startup-align 1 --short-temp NEW_ABSOLUTE_SHORT_TEMP
```

控制配置可显式使用 `--pll250 0 --startup-align 0`；单独比较时钟与新启动保持，可用0/1。生成的 wrapper OFF 层次为 network_clock/disabled/legacy，不能冒充原始原位层次；真正旧物理控制臂仍用原始未改工程。

installer 先验证既有 FINAL_SOURCE_MANIFEST 全部文件及309/82合同，再核对本次改动的已知前像。local-adapt-r3v 的完整当前文件集另作逐字节快照并保留，不用云端旧 monitor 覆盖；包括 reset-fold、reply-pruning、ordinary-batch、single-scan、audit-profile 等本地修正。只改5个 collector 与2个board源，增加明确列出的辅助文件。原manifest保存在provenance；新manifest保留所有未改条目。原 verify_handoff.py / bind_build_inputs.py 保持不变。遇到hash、anchor、路径或未知拓扑差异立即停，不自动放宽。

runner补丁要求两份实际min8文件命中已报告完整hash，并验证实际argc4、lassign argv→root/deps/raw50/python和同一行分号分隔的三个normalize语句。只替换root语句，保留deps/raw50；运行时ROOT参数必须等于NEW_NATIVE。python在mode hook之前已由该精确header定义。place的entry仍由当前脚本目录取得；未知header、entry/helper anchor或shortTemp行立即拒绝。

它复制到全新NEW_ENTRY，加入新clock模块、绑定四个显式generic，并使用新鲜synth/write/open checkpoint封装。require_vivado_min8.tcl必须是原entry的普通文件，原样复制到NEW_ENTRY并记录字节数和SHA256。其它未知外层helper不声称已自动处理；运行前按ACTUAL_RUNNER_CLOSURE.json（SHA256 7b9c91cf9712d416283c2aa9d873424a33206db6a038717354e5f6baf7d80536）逐项核对并准备其余依赖。外部PYTHON wrapper仍使用原argv路径，也须按该闭包核验。

--short-temp必须是本次独立、绝对且不存在的目录，替换已使用的valence-guarded19-place-r1硬编码路径；Python补丁时与生成Tcl运行时都拒绝既存目录。原TOP/PART、USER1/2、IP/ROM、monitor修正与顺序不动。这里只对已提供片段做mock；完整本地runner字节尚未在云端执行或重建。

## 本地接入与最后一个明确调用

synth与place使用同一个NEW_NATIVE。不能拿旧DCP替代新synth：原始open_checkpoint会清除当前消费状态；只有有当前source/fullmanifest hash与DCP hash收据的reopen可恢复。封装只在显式调用时运行。项目必须是原runner创建的新项目，按原完整309 RTL及board whitelist读入；磁盘preflight不独立证明Vivado内存中的compile-order闭包。

在route完成并为每档重新建立完整约束后，10/100/1000各执行一次：

```tcl
valence_network_postroute $rate $out
```

$rate为10/100/1000，$out为本次隔离implementation目录。该调用写入新的functional-reset-$rate目录，不能覆盖。现有片段未包含最终route/rate循环，所以不猜测插入位置，也不把未插入该调用的runner称为完整物理验收器。

此hook对每个确切reset源/汇分别查max和min：phase1/Q→RAW CLR（OFF另含PAD CLR）、原common reset→六ODDR RST与新hold PRE、hold/Q→全部fabric PRE/CLR；OFF也覆盖直接common→fabric。路径、实际端点、支持的EXCEPTION属性、有限requirement/slack必须存在；任何异常、缺失、负slack均失败并保留报告。报告应确认器件实际recovery/removal及同沿removal；4ns正沿/2ns负沿只是新fabric释放的名义关系。

## 拓扑/约束范围

- ON：PLLE4 CLKOUT0仍500MHz→delay BUFG；CLKOUT1为250MHz，直接分别驱动PAD BUFG与RAW BUFGCE_DIV2。
- 三级phase_reset在PAD边沿，stage1仅驱动stage2/D与RAW CLR；stage2参与qualified locked。inhibit和locked用实际有界LUT真值检查。
- primitive根为network_clock/enabled；实际模块接口根是network_clock。OFF为network_clock/disabled/legacy。实例唯一性、类型、极性、CE/CLR、REF500、真实波形、早级fanout均严格检查。
- 新hold是RAW正沿功能FF。ODDR仍用原SR，fabric复位单独延后一RAW；不加入ASYNC_REG豁免。
- 未增加false-path命令。旧三FF释放PRE豁免只迁移到被证明的对应链；功能CLR/SR和新hold全部保持时序。RX时序配方/引脚/预算不变，仅共享RAW祖先选择改变。

## 已有证据与限制

此前combined有限仿真用实际encoder、board reset fixture、当前0/0+startup固定源、官方归档ODDRE1；PLL/BUFG为ideal模型。ON/OFF各8个reset epoch，六类原因含三速hot-ready，8个首完整pair不跳warmup，22,297 half checks / 5,562 words；错误提前fabric释放被拒。combined FINAL_RECEIPT SHA256：4070d0c7600d89499d7b4273ff7d556f5a61d36fd474483a06091fd543bdae97。不是完整MAC/PHY或实际器件启动证明。原时钟单独候选因继承ODDR启动问题仍HOLD，本补丁明确引入独立startup fix，不回写旧结果。

新collector测试：47 clock/query、29 startup helper、28完整serializer audit、14 timing pair/query、24安装/绑定检查；安装测试嵌套两次各9个session/reopen mock；r3新增21项真实header/temp/helper定向检查，替代早期7项简化runner片段检查；其它测试未重跑。所有vendor查询、timing与DCP均为标明的mock，没有本地工具执行。原始当前whole-source控制lemma使用两套精确完整源hash；四个相关模块经保留预处理行边界的严格token比较完全相同，附16向量reset/phase归纳。

## 仍需本地验收

1. 安装前像与local-adapt快照通过；检查新root/entry/deps/raw50/python和完整compile-order。原始控制工程保持未改。
2. 本地实际ODDRE1版本与归档模型核对；新鲜综合后所有严格唯一性/物理属性检查通过，不能把mock结果写成vendor pass。
3. 原CPU/UART/IP/ROM、monitor reset-fold/pruning/performance、CDC/RDC与全部功能路径检查继续通过。
4. 每档插入上述postroute调用，检查functional recovery/removal、setup/hold、六输出三速边沿、unconstrained、DRC和完整时序。任何缺失/负值保留失败证据。
5. RX独立未闭合问题仍独立处理；此补丁不授权通过bitstream/发布门槛。
